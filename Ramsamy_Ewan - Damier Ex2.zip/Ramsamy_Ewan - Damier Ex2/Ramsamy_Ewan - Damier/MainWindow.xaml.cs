﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ramsamy_Ewan___Damier
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CreationDamier();
        }
        public void CreationDamier()
        {
            ColumnDefinition[] colonne = new ColumnDefinition[10];
            RowDefinition[] ligne = new RowDefinition[10];
            int chiffre = 1;
            Button[,] boutonM = new Button[10,10];

            for (int i = 0; i < colonne.Length; i++)
            {
                colonne[i] = new ColumnDefinition();
                ligne[i] = new RowDefinition();
                damier.RowDefinitions.Add(ligne[i]);
                damier.ColumnDefinitions.Add(colonne[i]);
            }
            for (int j = 0; j < 10; j++)
            {
                if (j% 2 == 0)
                {
                    for (int k = 0; k < 10; k++)
                    {
                        boutonM[j, k] = new Button();
                        boutonM[j, k].Content = chiffre;
                        boutonM[j, k].FontWeight = FontWeights.Bold;
                        boutonM[j, k].Foreground = Brushes.Red;

                        if ((j + k) % 2 == 1)
                        {
                            boutonM[j, k].Background = Brushes.White;
                        }
                        else
                        {
                            boutonM[j, k].Background = Brushes.Black;
                        }
                        Grid.SetRow(boutonM[j, k], j);
                        Grid.SetColumn(boutonM[j, k], k);
                        damier.Children.Add(boutonM[j, k]);
                        chiffre++;
                    }
                }
                else
                {
                    for (int k = 9; k > -1; k--)
                    {
                        boutonM[j, k] = new Button();
                        boutonM[j, k].Content = chiffre;
                        boutonM[j, k].FontWeight = FontWeights.Bold;
                        boutonM[j, k].Foreground = Brushes.Red;

                        if ((j + k) % 2 == 1)
                        {
                            boutonM[j, k].Background = Brushes.White;
                        }
                        else
                        {
                            boutonM[j, k].Background = Brushes.Black;
                        }
                        Grid.SetRow(boutonM[j, k], j);
                        Grid.SetColumn(boutonM[j, k], k);
                        damier.Children.Add(boutonM[j, k]);
                        chiffre++;
                    }
                }
                
            }
        }
    }
}
